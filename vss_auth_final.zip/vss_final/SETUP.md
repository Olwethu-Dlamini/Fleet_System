# Auth Setup — Vehicle Scheduling System

## Your users table — confirmed ✓
```
id, username, email, password_hash, full_name,
role (enum: admin/dispatcher/driver), is_active,
created_at, updated_at
```
**Adding 2 columns:** `refresh_token` and `last_login`

---

## STEP 1 — Run SQL migration (2 minutes)

phpMyAdmin → your database → SQL tab → paste and run:

```sql
ALTER TABLE `users`
  ADD COLUMN IF NOT EXISTS `refresh_token` TEXT NULL AFTER `role`;

ALTER TABLE `users`
  ADD COLUMN IF NOT EXISTS `last_login` DATETIME NULL AFTER `refresh_token`;
```

Your existing 5 users and their hashed passwords are untouched.

---

## STEP 2 — Install npm packages

```bash
cd your-backend-folder
npm install bcryptjs jsonwebtoken cookie-parser
```

---

## STEP 3 — Copy backend files

```
backend/config/auth.config.js         → your-backend/config/
backend/controllers/auth.controller.js → your-backend/controllers/
backend/middleware/auth.middleware.js  → your-backend/middleware/
backend/routes/auth.routes.js         → your-backend/routes/
```

---

## STEP 4 — Patch your app.js

Open `PATCH_YOUR_APP_JS.js` and follow the instructions.

**TL;DR — add these 4 things:**
```js
// At top:
const cookieParser       = require('cookie-parser');
const authRoutes         = require('./routes/auth.routes');
const { authMiddleware } = require('./middleware/auth.middleware');

// After pool creation:
app.locals.db = pool;

// After express.json():
app.use(cookieParser());
app.use('/api/auth', authRoutes);

// Protect existing routes:
app.use('/api/vehicles', authMiddleware, vehicleRoutes);
app.use('/api/jobs',     authMiddleware, jobRoutes);
// ... etc
```

---

## STEP 5 — Add .env variables

Add to your backend `.env`:
```
JWT_SECRET=vss_jwt_secret_CHANGE_IN_PROD_2024
JWT_REFRESH_SECRET=vss_refresh_secret_CHANGE_IN_PROD_2024
JWT_EXPIRES_IN=15m
JWT_REFRESH_EXPIRES=7d
```

---

## STEP 6 — Add Flutter packages

In `pubspec.yaml`, under `dependencies:`:
```yaml
provider: ^6.1.1
shared_preferences: ^2.2.2
```
Then: `flutter pub get`

---

## STEP 7 — Copy Flutter files

| File | Action |
|------|--------|
| `lib/config/app_config.dart` | **REPLACE** |
| `lib/services/api_service.dart` | **REPLACE** |
| `lib/main.dart` | **REPLACE** |
| `lib/models/user.dart` | **NEW** |
| `lib/services/auth_service.dart` | **NEW** |
| `lib/providers/auth_provider.dart` | **NEW** |
| `lib/screens/login_screen.dart` | **NEW** |

---

## STEP 8 — Test it

**Backend test:**
```bash
# Restart your server, then:
curl -X POST http://localhost:3000/api/auth/login \
  -H "Content-Type: application/json" \
  -d "{\"username\":\"admin\",\"password\":\"<your_admin_password>\"}"
```
Expected: `{ "success": true, "accessToken": "eyJ...", "user": {...} }`

**Flutter test:**
```bash
flutter run -d chrome
```
You should see the login screen → enter credentials → see the placeholder dashboard.

---

## How the auth flow works

```
App start
  → AuthGate.initState() calls checkAuthStatus()
  → Loads tokens from SharedPreferences
  → Pings /api/auth/me to verify

Token valid  → DashboardScreen (shows fullName + roleDisplayName)
Token expired → tries /api/auth/refresh → if ok, DashboardScreen
No token / all expired → LoginScreen

Login:
  POST /api/auth/login
  → stores accessToken + refreshToken in SharedPreferences
  → AuthStatus.authenticated → DashboardScreen

Every other API call:
  ApiService._headers auto-injects: Authorization: Bearer <accessToken>
  No changes needed in VehicleService / JobService

Logout:
  POST /api/auth/logout (clears DB refresh_token)
  → clears SharedPreferences
  → AuthStatus.unauthenticated → LoginScreen
```

---

## Your accounts (use existing passwords)

| username | role |
|----------|------|
| admin | Administrator |
| dispatcher1 | Dispatcher |
| driver1 | Driver |
| driver2 | Driver |
| driver3 | Driver |
