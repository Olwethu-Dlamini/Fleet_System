// ============================================================
// FILE: PATCH_YOUR_APP_JS.js
// PURPOSE: Exact lines to add to your existing app.js / server.js
// DO NOT replace your file — just copy the marked lines in.
// ============================================================

// ── STEP 1 ─────────────────────────────────────────────────────────────────────
// Run this in your backend folder:
//
//   npm install bcryptjs jsonwebtoken cookie-parser

// ── STEP 2: Add these 3 requires near the top of app.js ───────────────────────

const cookieParser       = require('cookie-parser');
const authRoutes         = require('./routes/auth.routes');
const { authMiddleware } = require('./middleware/auth.middleware');

// ── STEP 3: Attach your pool after you create it ──────────────────────────────
//
// Find the line where you create your MySQL pool, e.g.:
//   const pool = mysql.createPool({ ... });
//
// Add immediately after:

app.locals.db = pool;   // ← auth controller reads db via req.app.locals.db

// ── STEP 4: Add cookieParser BEFORE your route blocks ─────────────────────────

app.use(cookieParser());

// ── STEP 5: Mount auth routes (no authMiddleware — these are public) ──────────

app.use('/api/auth', authRoutes);

// ── STEP 6: Protect your existing routes ─────────────────────────────────────
//
// Change from:
//   app.use('/api/vehicles', vehicleRoutes);
//   app.use('/api/jobs',     jobRoutes);
//   ...
//
// To:
//   app.use('/api/vehicles',        authMiddleware, vehicleRoutes);
//   app.use('/api/jobs',            authMiddleware, jobRoutes);
//   app.use('/api/job-assignments', authMiddleware, assignmentRoutes);
//   app.use('/api/job-status',      authMiddleware, statusRoutes);
//   app.use('/api/dashboard',       authMiddleware, dashboardRoutes);
//   app.use('/api/reports',         authMiddleware, reportRoutes);

// ── STEP 7: Create .env in your backend root ──────────────────────────────────
//
// Add these lines (or add to existing .env):
//
// JWT_SECRET=vss_jwt_secret_CHANGE_IN_PROD_2024
// JWT_REFRESH_SECRET=vss_refresh_secret_CHANGE_IN_PROD_2024
// JWT_EXPIRES_IN=15m
// JWT_REFRESH_EXPIRES=7d
// NODE_ENV=development

// ── STEP 8: Test ──────────────────────────────────────────────────────────────
//
// Restart your server then run:
//
//   curl -X POST http://localhost:3000/api/auth/login \
//     -H "Content-Type: application/json" \
//     -d "{\"username\":\"admin\",\"password\":\"your_admin_password\"}"
//
// Expected response:
//   {
//     "success": true,
//     "accessToken": "eyJhbGci...",
//     "refreshToken": "eyJhbGci...",
//     "user": { "id": 1, "username": "admin", "full_name": "System Admin", ... }
//   }

// ── COMPLETE EXAMPLE app.js for reference ────────────────────────────────────
/*
const express      = require('express');
const cors         = require('cors');
const mysql        = require('mysql2/promise');
const cookieParser = require('cookie-parser');  // ← NEW
require('dotenv').config();

const authRoutes         = require('./routes/auth.routes');   // ← NEW
const vehicleRoutes      = require('./routes/vehicle.routes');
const jobRoutes          = require('./routes/job.routes');
const { authMiddleware } = require('./middleware/auth.middleware'); // ← NEW

const app  = express();
const PORT = process.env.PORT || 3000;

const pool = mysql.createPool({
  host:     process.env.DB_HOST     || 'localhost',
  user:     process.env.DB_USER     || 'root',
  password: process.env.DB_PASSWORD || '',
  database: process.env.DB_NAME     || 'vehicle_scheduling',
});
app.locals.db = pool;   // ← NEW

app.use(cors({ origin: true, credentials: true }));
app.use(express.json());
app.use(cookieParser());   // ← NEW

app.use('/api/auth',            authRoutes);                       // ← NEW
app.use('/api/vehicles',        authMiddleware, vehicleRoutes);    // ← UPDATED
app.use('/api/jobs',            authMiddleware, jobRoutes);        // ← UPDATED
app.use('/api/job-assignments', authMiddleware, assignmentRoutes); // ← UPDATED
app.use('/api/job-status',      authMiddleware, statusRoutes);     // ← UPDATED
app.use('/api/dashboard',       authMiddleware, dashboardRoutes);  // ← UPDATED

app.listen(PORT, () => console.log(`Server on port ${PORT}`));
*/
