// ============================================================
// FILE: config/auth.config.js
// ============================================================
// NOTE: Your existing passwords were hashed with bcrypt rounds=10.
// We use saltRounds: 10 here to match so new passwords are consistent.
// You can raise this to 12 for new accounts without breaking existing ones
// (bcrypt self-describes its rounds inside the hash string).

module.exports = {
  jwt: {
    secret:           process.env.JWT_SECRET          || 'vss_jwt_secret_CHANGE_IN_PROD_2024',
    refreshSecret:    process.env.JWT_REFRESH_SECRET  || 'vss_refresh_secret_CHANGE_IN_PROD_2024',
    expiresIn:        process.env.JWT_EXPIRES_IN      || '15m',
    refreshExpiresIn: process.env.JWT_REFRESH_EXPIRES || '7d',
    algorithm:        'HS256',
  },
  bcrypt: {
    saltRounds: 10, // matches your existing hashes
  },
  cookie: {
    httpOnly: true,
    secure:   process.env.NODE_ENV === 'production',
    sameSite: 'Strict',
    maxAge:   7 * 24 * 60 * 60 * 1000, // 7 days
  },
};
