// ============================================================
// FILE: controllers/auth.controller.js
// ============================================================
// Column mapping (verified against your DESCRIBE output):
//   password  → password_hash   ✓
//   name      → full_name       ✓
//   role      → role            ✓  enum('admin','dispatcher','driver')
//   active    → is_active       ✓  tinyint(1)
//   new cols  → refresh_token, last_login (added by SQL migration)

const bcrypt  = require('bcryptjs');
const jwt     = require('jsonwebtoken');
const authCfg = require('../config/auth.config');

// ── Private helpers ────────────────────────────────────────────────────────────

function signAccessToken(payload) {
  return jwt.sign(payload, authCfg.jwt.secret, {
    algorithm: authCfg.jwt.algorithm,
    expiresIn: authCfg.jwt.expiresIn,
  });
}

function signRefreshToken(payload) {
  return jwt.sign(payload, authCfg.jwt.refreshSecret, {
    algorithm: authCfg.jwt.algorithm,
    expiresIn: authCfg.jwt.refreshExpiresIn,
  });
}

/** Remove sensitive columns before sending to Flutter */
function sanitizeUser(user) {
  const { password_hash, refresh_token, ...safe } = user;
  return safe;
}

// ── POST /api/auth/login ───────────────────────────────────────────────────────
// Body:    { username, password }
// Returns: { success, accessToken, refreshToken, user }
exports.login = async (req, res) => {
  const db = req.app.locals.db;

  try {
    const { username, password } = req.body;

    if (!username || !password) {
      return res.status(400).json({
        success: false,
        message: 'Username and password are required.',
      });
    }

    // Accept login by username OR email
    // Selects exactly the columns your table has
    const [rows] = await db.query(
      `SELECT id, username, email, password_hash, full_name,
              role, is_active, last_login, created_at
       FROM   users
       WHERE  (username = ? OR email = ?)
         AND  is_active = 1
       LIMIT  1`,
      [username, username]
    );

    if (!rows.length) {
      // Same message for "not found" and "wrong password" — prevents username enumeration
      return res.status(401).json({
        success: false,
        message: 'Invalid username or password.',
      });
    }

    const user = rows[0];

    const valid = await bcrypt.compare(password, user.password_hash);
    if (!valid) {
      return res.status(401).json({
        success: false,
        message: 'Invalid username or password.',
      });
    }

    const tokenPayload = { id: user.id, username: user.username, role: user.role };
    const accessToken  = signAccessToken(tokenPayload);
    const refreshToken = signRefreshToken(tokenPayload);

    // Persist refresh token + stamp last_login
    await db.query(
      'UPDATE users SET refresh_token = ?, last_login = NOW() WHERE id = ?',
      [refreshToken, user.id]
    );

    // Set as HttpOnly cookie for web clients
    res.cookie('refreshToken', refreshToken, authCfg.cookie);

    return res.status(200).json({
      success:      true,
      message:      'Login successful.',
      accessToken,
      refreshToken, // also in body so Flutter can store in SharedPreferences
      user:         sanitizeUser(user),
    });

  } catch (err) {
    console.error('[auth/login]', err);
    return res.status(500).json({ success: false, message: 'Server error during login.' });
  }
};

// ── POST /api/auth/refresh ────────────────────────────────────────────────────
// Body:    { refreshToken }  OR cookie
// Returns: { success, accessToken, refreshToken }
exports.refresh = async (req, res) => {
  const db = req.app.locals.db;

  try {
    const token = req.cookies?.refreshToken || req.body?.refreshToken;

    if (!token) {
      return res.status(401).json({
        success: false,
        message: 'Refresh token required.',
        code:    'NO_REFRESH_TOKEN',
      });
    }

    let decoded;
    try {
      decoded = jwt.verify(token, authCfg.jwt.refreshSecret);
    } catch {
      return res.status(401).json({
        success: false,
        message: 'Session expired. Please log in again.',
        code:    'REFRESH_EXPIRED',
      });
    }

    // Confirm token still matches DB row (detects reuse of old rotated tokens)
    const [rows] = await db.query(
      `SELECT id, username, role
       FROM   users
       WHERE  id = ? AND refresh_token = ? AND is_active = 1
       LIMIT  1`,
      [decoded.id, token]
    );

    if (!rows.length) {
      return res.status(401).json({
        success: false,
        message: 'Session revoked. Please log in again.',
        code:    'TOKEN_REVOKED',
      });
    }

    const user = rows[0];
    const tokenPayload = { id: user.id, username: user.username, role: user.role };

    // Rotate — old refresh token is now invalid
    const newAccessToken  = signAccessToken(tokenPayload);
    const newRefreshToken = signRefreshToken(tokenPayload);

    await db.query(
      'UPDATE users SET refresh_token = ? WHERE id = ?',
      [newRefreshToken, user.id]
    );
    res.cookie('refreshToken', newRefreshToken, authCfg.cookie);

    return res.status(200).json({
      success:      true,
      accessToken:  newAccessToken,
      refreshToken: newRefreshToken,
    });

  } catch (err) {
    console.error('[auth/refresh]', err);
    return res.status(500).json({ success: false, message: 'Server error during refresh.' });
  }
};

// ── POST /api/auth/logout ─────────────────────────────────────────────────────
// Requires: Authorization: Bearer <token>
// Returns:  { success, message }
exports.logout = async (req, res) => {
  const db = req.app.locals.db;

  try {
    if (req.user?.id) {
      await db.query(
        'UPDATE users SET refresh_token = NULL WHERE id = ?',
        [req.user.id]
      );
    }
    res.clearCookie('refreshToken');
    return res.status(200).json({ success: true, message: 'Logged out.' });

  } catch (err) {
    console.error('[auth/logout]', err);
    return res.status(500).json({ success: false, message: 'Server error during logout.' });
  }
};

// ── GET /api/auth/me ──────────────────────────────────────────────────────────
// Requires: Authorization: Bearer <token>
// Returns:  { success, user }
exports.me = async (req, res) => {
  const db = req.app.locals.db;

  try {
    const [rows] = await db.query(
      `SELECT id, username, email, full_name, role,
              is_active, last_login, created_at
       FROM   users
       WHERE  id = ? AND is_active = 1
       LIMIT  1`,
      [req.user.id]
    );

    if (!rows.length) {
      return res.status(404).json({ success: false, message: 'User not found.' });
    }

    return res.status(200).json({ success: true, user: rows[0] });

  } catch (err) {
    console.error('[auth/me]', err);
    return res.status(500).json({ success: false, message: 'Server error.' });
  }
};
