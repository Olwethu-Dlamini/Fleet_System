// ============================================================
// FILE: middleware/auth.middleware.js
// ============================================================

const jwt     = require('jsonwebtoken');
const authCfg = require('../config/auth.config');

/**
 * Verifies JWT Bearer token on protected routes.
 * Usage:  router.get('/path', authMiddleware, handler)
 * Sets:   req.user = { id, username, role, iat, exp }
 */
function authMiddleware(req, res, next) {
  const authHeader = req.headers['authorization'] || req.headers['Authorization'];

  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({
      success: false,
      message: 'No access token provided. Please log in.',
      code:    'NO_TOKEN',
    });
  }

  const token = authHeader.split(' ')[1];

  try {
    const decoded = jwt.verify(token, authCfg.jwt.secret, {
      algorithms: [authCfg.jwt.algorithm],
    });
    req.user = decoded; // { id, username, role, iat, exp }
    next();
  } catch (err) {
    if (err.name === 'TokenExpiredError') {
      return res.status(401).json({
        success: false,
        message: 'Session expired. Please refresh your token.',
        code:    'TOKEN_EXPIRED',
      });
    }
    return res.status(401).json({
      success: false,
      message: 'Invalid access token.',
      code:    'INVALID_TOKEN',
    });
  }
}

/**
 * Role guard factory.
 * Usage:  requireRole('admin')
 *         requireRole('admin', 'dispatcher')
 */
function requireRole(...roles) {
  return (req, res, next) => {
    if (!req.user) {
      return res.status(401).json({ success: false, message: 'Not authenticated.' });
    }
    if (!roles.includes(req.user.role)) {
      return res.status(403).json({
        success: false,
        message: `Access denied. Requires: ${roles.join(' or ')}`,
        code:    'FORBIDDEN',
      });
    }
    next();
  };
}

module.exports = { authMiddleware, requireRole };
