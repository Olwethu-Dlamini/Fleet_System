// ============================================================
// FILE: routes/auth.routes.js
// ============================================================

const express    = require('express');
const router     = express.Router();
const controller = require('../controllers/auth.controller');
const { authMiddleware } = require('../middleware/auth.middleware');

// Public — no token required
router.post('/login',   controller.login);
router.post('/refresh', controller.refresh);

// Protected — token required
router.post('/logout', authMiddleware, controller.logout);
router.get('/me',      authMiddleware, controller.me);

module.exports = router;
