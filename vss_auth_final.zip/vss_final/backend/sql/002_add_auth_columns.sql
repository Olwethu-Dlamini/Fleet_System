-- ============================================================
-- FILE: sql/002_add_auth_columns.sql
-- PURPOSE: Add only the 2 missing columns to your users table
--
-- YOUR EXISTING COLUMNS (verified — do NOT touch):
--   id, username, email, password_hash, full_name,
--   role, is_active, created_at, updated_at  ← all fine
--
-- ADDING:
--   refresh_token  → stores JWT refresh token for rotation
--   last_login     → records when user last signed in
--
-- SAFE: IF NOT EXISTS means this can be run multiple times.
-- ============================================================

ALTER TABLE `users`
  ADD COLUMN IF NOT EXISTS `refresh_token` TEXT NULL
    AFTER `role`;

ALTER TABLE `users`
  ADD COLUMN IF NOT EXISTS `last_login` DATETIME NULL
    AFTER `refresh_token`;

-- ============================================================
-- VERIFY: run this to confirm columns were added
-- ============================================================
-- DESCRIBE users;
-- Expected new columns: refresh_token (TEXT, NULL), last_login (DATETIME, NULL)
