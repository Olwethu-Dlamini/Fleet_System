// ============================================
// FILE: lib/config/app_config.dart
// PURPOSE: App-wide configuration and API settings
//
// HOW ENDPOINTS WORK:
//   baseUrl  = 'http://localhost:3000/api'
//   endpoint = '/vehicles'
//   ApiService builds full URL = baseUrl + endpoint
//                              = 'http://localhost:3000/api/vehicles'
//
// NEVER bake the full URL into an endpoint constant.
// Endpoints must always be a short relative path like '/jobs'
// ============================================

class AppConfig {
  // ==========================================
  // BASE URLs - one per environment
  // ==========================================

  // Chrome / Web browser
  static const String baseUrlWeb = 'http://localhost:3000/api';

  // Android Emulator (10.0.2.2 maps to your PC localhost)
  static const String baseUrlAndroid = 'http://10.0.2.2:3000/api';

  // Real Android device on same WiFi
  // Run: ipconfig (Windows) → find IPv4 Address → paste here
  static const String baseUrlDevice = 'http://192.168.1.100:3000/api';

  // ==========================================
  // ACTIVE BASE URL
  // Change this ONE line to switch environments
  // ==========================================
  static String get baseUrl => baseUrlWeb;

  // ==========================================
  // AUTH ENDPOINTS  ← NEW
  // ==========================================
  static const String loginEndpoint   = '/auth/login';
  static const String refreshEndpoint = '/auth/refresh';
  static const String logoutEndpoint  = '/auth/logout';
  static const String meEndpoint      = '/auth/me';

  // ==========================================
  // TOKEN STORAGE KEYS  ← NEW
  // Keys used by SharedPreferences
  // ==========================================
  static const String accessTokenKey  = 'vss_access_token';
  static const String refreshTokenKey = 'vss_refresh_token';
  static const String userDataKey     = 'vss_user_data';

  // ==========================================
  // API ENDPOINTS  ← unchanged from original
  // ==========================================
  static const String healthEndpoint      = '/health';
  static const String vehiclesEndpoint    = '/vehicles';
  static const String jobsEndpoint        = '/jobs';
  static const String assignmentsEndpoint = '/job-assignments';
  static const String statusEndpoint      = '/job-status';
  static const String dashboardEndpoint   = '/dashboard';
  static const String reportsEndpoint     = '/reports';

  // ==========================================
  // HTTP TIMEOUT  ← unchanged
  // ==========================================
  static const Duration connectionTimeout = Duration(seconds: 30);
  static const Duration receiveTimeout    = Duration(seconds: 30);

  // ==========================================
  // APP INFO  ← unchanged
  // ==========================================
  static const String appName    = 'Vehicle Scheduling';
  static const String appVersion = '1.0.0';

  // ==========================================
  // DEFAULT USER ID  ← unchanged
  // ==========================================
  static const int defaultUserId = 1;
}
