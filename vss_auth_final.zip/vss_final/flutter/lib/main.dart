// ============================================
// FILE: lib/main.dart
// PURPOSE: App entry point + auth-based routing
//
// UNCHANGED from your original structure.
// The DashboardScreen placeholder below is identical to yours.
// Replace it with your real DashboardScreen when built.
// ============================================

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:vehicle_scheduling_app/config/theme.dart';
import 'package:vehicle_scheduling_app/providers/auth_provider.dart';
import 'package:vehicle_scheduling_app/screens/login_screen.dart';

// ============================================
// PLACEHOLDER DASHBOARD
// Keep this until dashboard_screen.dart is ready.
// Then replace with:
//   import 'package:vehicle_scheduling_app/screens/dashboard/dashboard_screen.dart';
// And change `return const DashboardScreen();` in AuthGate.
// ============================================
class DashboardScreen extends StatelessWidget {
  const DashboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Dashboard'),
        actions: [
          IconButton(
            icon:    const Icon(Icons.logout),
            tooltip: 'Logout',
            onPressed: () => context.read<AuthProvider>().logout(),
          ),
        ],
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(
              Icons.check_circle,
              size:  80,
              color: AppTheme.successColor,
            ),
            const SizedBox(height: 20),
            Text(
              'Welcome, ${auth.user?.fullName ?? 'User'}!',
              style: const TextStyle(
                fontSize:   24,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              'Role: ${auth.user?.roleDisplayName ?? ''}',
              style: const TextStyle(
                fontSize: 16,
                color:    AppTheme.textSecondary,
              ),
            ),
            const SizedBox(height: 40),
            const Text(
              'Dashboard coming next...',
              style: TextStyle(color: AppTheme.textHint),
            ),
          ],
        ),
      ),
    );
  }
}

// ============================================
// MAIN ENTRY POINT
// ============================================
void main() {
  runApp(
    MultiProvider(
      providers: [ChangeNotifierProvider(create: (_) => AuthProvider())],
      child: const VehicleSchedulingApp(),
    ),
  );
}

class VehicleSchedulingApp extends StatelessWidget {
  const VehicleSchedulingApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title:                     'Vehicle Scheduling',
      theme:                     AppTheme.lightTheme,
      debugShowCheckedModeBanner: false,
      home: const AuthGate(),
    );
  }
}

// ============================================
// AUTH GATE
// Watches AuthProvider and routes accordingly.
// Reactive — no manual Navigator.push needed anywhere.
// ============================================
class AuthGate extends StatefulWidget {
  const AuthGate({super.key});

  @override
  State<AuthGate> createState() => _AuthGateState();
}

class _AuthGateState extends State<AuthGate> {
  @override
  void initState() {
    super.initState();
    // Check stored token once on app launch
    Future.microtask(() {
      context.read<AuthProvider>().checkAuthStatus();
    });
  }

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();

    // Checking stored token → splash screen
    if (auth.status == AuthStatus.unknown) {
      return const Scaffold(
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(
                Icons.local_shipping,
                size:  60,
                color: AppTheme.primaryColor,
              ),
              SizedBox(height: 20),
              CircularProgressIndicator(),
              SizedBox(height: 16),
              Text('Loading...'),
            ],
          ),
        ),
      );
    }

    // Not logged in → login screen
    if (auth.status == AuthStatus.unauthenticated) {
      return const LoginScreen();
    }

    // Logged in → dashboard
    return const DashboardScreen();
  }
}
