// ============================================
// FILE: lib/models/user.dart
// PURPOSE: User data model
//
// Column mapping (verified from your DESCRIBE output):
//   DB column      → Dart field
//   id             → id
//   username       → username
//   email          → email
//   full_name      → fullName
//   role           → role  ('admin'|'dispatcher'|'driver')
//   is_active      → isActive
//   last_login     → lastLogin   (nullable)
//   created_at     → createdAt
//   updated_at     → updatedAt
//
// main.dart uses:
//   auth.user?.fullName         ← mapped here
//   auth.user?.roleDisplayName  ← computed getter here
// ============================================

class User {
  final int     id;
  final String  username;
  final String  email;
  final String  fullName;
  final String  role;
  final bool    isActive;
  final String? lastLogin;
  final String? createdAt;
  final String? updatedAt;

  const User({
    required this.id,
    required this.username,
    required this.email,
    required this.fullName,
    required this.role,
    required this.isActive,
    this.lastLogin,
    this.createdAt,
    this.updatedAt,
  });

  // ============================================
  // FROM JSON
  // Parses the backend /api/auth/login and /api/auth/me response
  // ============================================
  factory User.fromJson(Map<String, dynamic> json) {
    return User(
      id:        json['id']        as int,
      username:  json['username']  as String,
      email:     json['email']     as String,
      fullName:  json['full_name'] as String,   // DB: full_name ✓
      role:      json['role']      as String,
      isActive:  (json['is_active'] == 1 || json['is_active'] == true),
      lastLogin: json['last_login'] as String?,
      createdAt: json['created_at'] as String?,
      updatedAt: json['updated_at'] as String?,
    );
  }

  // ============================================
  // TO JSON
  // Used when saving user to SharedPreferences
  // ============================================
  Map<String, dynamic> toJson() => {
    'id':         id,
    'username':   username,
    'email':      email,
    'full_name':  fullName,
    'role':       role,
    'is_active':  isActive ? 1 : 0,
    'last_login': lastLogin,
    'created_at': createdAt,
    'updated_at': updatedAt,
  };

  // ============================================
  // DISPLAY GETTERS
  // ============================================

  /// Used by main.dart:  auth.user?.roleDisplayName
  String get roleDisplayName {
    switch (role.toLowerCase()) {
      case 'admin':      return 'Administrator';
      case 'dispatcher': return 'Dispatcher';
      case 'driver':     return 'Driver';
      default:           return role;
    }
  }

  /// Initials for avatar  e.g. "System Admin" → "SA", "Mike Driver" → "MD"
  String get initials {
    final parts = fullName.trim().split(' ');
    if (parts.length >= 2) {
      return '${parts.first[0]}${parts.last[0]}'.toUpperCase();
    }
    return fullName.isNotEmpty ? fullName[0].toUpperCase() : '?';
  }

  // ============================================
  // PERMISSION HELPERS
  // Use in screens to show/hide actions by role
  // ============================================
  bool get isAdmin      => role == 'admin';
  bool get isDispatcher => role == 'dispatcher' || role == 'admin';
  bool get isDriver     => role == 'driver';

  bool get canManageJobs  => isAdmin || isDispatcher;
  bool get canAssignJobs  => isAdmin || isDispatcher;
  bool get canUpdateStatus => true; // all roles can update status
}
