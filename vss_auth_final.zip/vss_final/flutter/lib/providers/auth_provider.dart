// ============================================
// FILE: lib/providers/auth_provider.dart
// PURPOSE: Auth state management for the widget tree
//
// main.dart already references these — all implemented here:
//   AuthStatus.unknown          (app loading)
//   AuthStatus.unauthenticated  (not logged in)
//   auth.status                 (watched by AuthGate)
//   auth.user?.fullName         (shown in DashboardScreen)
//   auth.user?.roleDisplayName  (shown in DashboardScreen)
//   AuthProvider().checkAuthStatus()  (called in AuthGate.initState)
//   AuthProvider().logout()           (called from logout button)
// ============================================

import 'package:flutter/foundation.dart';
import 'package:vehicle_scheduling_app/models/user.dart';
import 'package:vehicle_scheduling_app/services/auth_service.dart';

// ============================================
// AUTH STATUS — matches AuthGate checks in main.dart
// ============================================
enum AuthStatus {
  unknown,        // App just started, checking stored token
  authenticated,  // Logged in and token is valid
  unauthenticated // Logged out or token expired
}

class AuthProvider extends ChangeNotifier {
  final AuthService _auth = AuthService();

  AuthStatus _status       = AuthStatus.unknown;
  String?    _errorMessage;
  bool       _isLoading    = false;

  // ── Getters ───────────────────────────────────────────────────────────────

  AuthStatus get status       => _status;
  String?    get errorMessage => _errorMessage;
  bool       get isLoading    => _isLoading;

  /// main.dart: auth.user?.fullName
  /// main.dart: auth.user?.roleDisplayName
  User? get user => _auth.currentUser;

  bool get isAuthenticated => _status == AuthStatus.authenticated;

  // ============================================
  // CHECK AUTH STATUS
  // Called by AuthGate.initState() via:
  //   context.read<AuthProvider>().checkAuthStatus()
  //
  // Flow:
  //   1. Load saved tokens from SharedPreferences
  //   2. Ping /api/auth/me to verify token is still valid
  //   3. On 401, try refreshing the token
  //   4. Set status → AuthGate re-renders the right screen
  // ============================================
  Future<void> checkAuthStatus() async {
    _status = AuthStatus.unknown;
    notifyListeners();

    await _auth.init(); // load saved tokens

    if (!_auth.isLoggedIn) {
      _status = AuthStatus.unauthenticated;
      notifyListeners();
      return;
    }

    final valid = await _auth.validateToken();
    _status = valid ? AuthStatus.authenticated : AuthStatus.unauthenticated;
    notifyListeners();
  }

  // ============================================
  // LOGIN
  // Called by LoginScreen:
  //   final ok = await context.read<AuthProvider>().login(user, pass);
  //
  // On success → status becomes authenticated → AuthGate shows Dashboard
  // On failure → errorMessage set → LoginScreen shows error banner
  // ============================================
  Future<bool> login(String username, String password) async {
    _isLoading    = true;
    _errorMessage = null;
    notifyListeners();

    final result = await _auth.login(username: username, password: password);

    _isLoading = false;

    if (result['success'] == true) {
      _status       = AuthStatus.authenticated;
      _errorMessage = null;
    } else {
      _status       = AuthStatus.unauthenticated;
      _errorMessage = result['message'] as String? ?? 'Login failed.';
    }

    notifyListeners();
    return result['success'] == true;
  }

  // ============================================
  // LOGOUT
  // Called from DashboardScreen logout button:
  //   context.read<AuthProvider>().logout()
  //
  // Clears tokens + status → AuthGate shows LoginScreen
  // ============================================
  Future<void> logout() async {
    _isLoading = true;
    notifyListeners();

    await _auth.logout();

    _status       = AuthStatus.unauthenticated;
    _errorMessage = null;
    _isLoading    = false;
    notifyListeners();
  }

  // ============================================
  // CLEAR ERROR
  // Call before retrying login so old error disappears
  // ============================================
  void clearError() {
    if (_errorMessage != null) {
      _errorMessage = null;
      notifyListeners();
    }
  }
}
