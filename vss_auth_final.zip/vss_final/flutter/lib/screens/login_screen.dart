// ============================================
// FILE: lib/screens/login_screen.dart
//
// Import path matches main.dart exactly:
//   import 'package:vehicle_scheduling_app/screens/login_screen.dart';
//
// Styled with your AppTheme constants:
//   primaryColor   = Color(0xFF2196F3)
//   backgroundColor = Color(0xFFF5F5F5)
//   cardColor      = Colors.white
//   textPrimary    = Color(0xFF212121)
//   textSecondary  = Color(0xFF757575)
//   textHint       = Color(0xFF9E9E9E)
//   errorColor     = Color(0xFFF44336)
//   Input borders  = radius 8, same as inputDecorationTheme
//   Card           = radius 12, elevation 2 (CardTheme)
// ============================================

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:vehicle_scheduling_app/config/theme.dart';
import 'package:vehicle_scheduling_app/providers/auth_provider.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _formKey   = GlobalKey<FormState>();
  final _userCtrl  = TextEditingController();
  final _passCtrl  = TextEditingController();
  final _userFocus = FocusNode();
  final _passFocus = FocusNode();

  bool _obscurePassword = true;

  @override
  void dispose() {
    _userCtrl.dispose();
    _passCtrl.dispose();
    _userFocus.dispose();
    _passFocus.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    FocusScope.of(context).unfocus();
    if (!_formKey.currentState!.validate()) return;

    context.read<AuthProvider>().clearError();
    await context.read<AuthProvider>().login(
      _userCtrl.text.trim(),
      _passCtrl.text,
    );
    // AuthGate in main.dart reacts automatically — no Navigator.push needed
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.backgroundColor,
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 32),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 400),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  _buildHeader(),
                  const SizedBox(height: 32),
                  _buildFormCard(),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  // ── Header: logo + title ──────────────────────────────────────────────────

  Widget _buildHeader() {
    return Column(
      children: [
        Container(
          width:  72,
          height: 72,
          decoration: BoxDecoration(
            color:        AppTheme.primaryColor,
            borderRadius: BorderRadius.circular(16),
            boxShadow: [
              BoxShadow(
                color:      AppTheme.primaryColor.withOpacity(0.35),
                blurRadius: 16,
                offset:     const Offset(0, 6),
              ),
            ],
          ),
          child: const Icon(
            Icons.local_shipping,
            color: AppTheme.textWhite,
            size:  38,
          ),
        ),
        const SizedBox(height: 20),
        const Text(
          'Vehicle Scheduling',
          style: TextStyle(
            fontSize:   26,
            fontWeight: FontWeight.bold,
            color:      AppTheme.textPrimary,
          ),
          textAlign: TextAlign.center,
        ),
        const SizedBox(height: 6),
        const Text(
          'Sign in to your account',
          style: TextStyle(
            fontSize: 14,
            color:    AppTheme.textSecondary,
          ),
          textAlign: TextAlign.center,
        ),
      ],
    );
  }

  // ── Form card ─────────────────────────────────────────────────────────────

  Widget _buildFormCard() {
    return Card(
      // Uses AppTheme.cardTheme: white, elevation 2, radius 12
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // Error banner
              _ErrorBanner(),

              // Username label + field
              _fieldLabel('Username or Email'),
              const SizedBox(height: 8),
              TextFormField(
                controller:      _userCtrl,
                focusNode:       _userFocus,
                keyboardType:    TextInputType.emailAddress,
                textInputAction: TextInputAction.next,
                autocorrect:     false,
                onFieldSubmitted: (_) => _passFocus.requestFocus(),
                decoration: const InputDecoration(
                  hintText:   'Enter username or email',
                  prefixIcon: Icon(Icons.person_outline, size: 20),
                ),
                validator: (v) => (v == null || v.trim().isEmpty)
                    ? 'Username is required'
                    : null,
              ),
              const SizedBox(height: 20),

              // Password label + field
              _fieldLabel('Password'),
              const SizedBox(height: 8),
              TextFormField(
                controller:      _passCtrl,
                focusNode:       _passFocus,
                obscureText:     _obscurePassword,
                textInputAction: TextInputAction.done,
                onFieldSubmitted: (_) => _submit(),
                decoration: InputDecoration(
                  hintText:   'Enter password',
                  prefixIcon: const Icon(Icons.lock_outline, size: 20),
                  suffixIcon: IconButton(
                    icon: Icon(
                      _obscurePassword
                          ? Icons.visibility_off_outlined
                          : Icons.visibility_outlined,
                      size:  20,
                      color: AppTheme.textSecondary,
                    ),
                    onPressed: () =>
                        setState(() => _obscurePassword = !_obscurePassword),
                  ),
                ),
                validator: (v) {
                  if (v == null || v.isEmpty) return 'Password is required';
                  if (v.length < 6) return 'Password must be at least 6 characters';
                  return null;
                },
              ),
              const SizedBox(height: 28),

              // Sign in button
              _SignInButton(onPressed: _submit),
              const SizedBox(height: 20),

              // Demo accounts hint
              _DemoHint(),
            ],
          ),
        ),
      ),
    );
  }

  Widget _fieldLabel(String text) {
    return Text(
      text,
      style: const TextStyle(
        fontSize:   13,
        fontWeight: FontWeight.w600,
        color:      AppTheme.textPrimary,
      ),
    );
  }
}

// ── Error banner ──────────────────────────────────────────────────────────────

class _ErrorBanner extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final error = context.watch<AuthProvider>().errorMessage;
    if (error == null) return const SizedBox.shrink();

    return Container(
      margin:  const EdgeInsets.only(bottom: 20),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(
        color:        AppTheme.errorColor.withOpacity(0.08),
        borderRadius: BorderRadius.circular(8),
        border:       Border.all(color: AppTheme.errorColor.withOpacity(0.3)),
      ),
      child: Row(
        children: [
          const Icon(Icons.error_outline, color: AppTheme.errorColor, size: 18),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              error,
              style: const TextStyle(color: AppTheme.errorColor, fontSize: 13),
            ),
          ),
        ],
      ),
    );
  }
}

// ── Sign in button ────────────────────────────────────────────────────────────

class _SignInButton extends StatelessWidget {
  const _SignInButton({required this.onPressed});
  final VoidCallback onPressed;

  @override
  Widget build(BuildContext context) {
    final isLoading = context.watch<AuthProvider>().isLoading;

    return SizedBox(
      height: 48,
      child: ElevatedButton(
        // Uses AppTheme.elevatedButtonTheme: primaryColor bg, white text, radius 8
        onPressed: isLoading ? null : onPressed,
        child: isLoading
            ? const SizedBox(
                width:  22,
                height: 22,
                child:  CircularProgressIndicator(
                  strokeWidth: 2.5,
                  color:       AppTheme.textWhite,
                ),
              )
            : const Text(
                'Sign In',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
              ),
      ),
    );
  }
}

// ── Demo hint — shows your 5 real usernames ───────────────────────────────────

class _DemoHint extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color:        AppTheme.primaryColor.withOpacity(0.05),
        borderRadius: BorderRadius.circular(8),
        border:       Border.all(color: AppTheme.primaryColor.withOpacity(0.15)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Row(
            children: [
              Icon(Icons.info_outline, size: 14, color: AppTheme.primaryColor),
              SizedBox(width: 6),
              Text(
                'Test Accounts',
                style: TextStyle(
                  fontSize:   11,
                  fontWeight: FontWeight.w700,
                  color:      AppTheme.primaryColor,
                ),
              ),
            ],
          ),
          const SizedBox(height: 6),
          // Your 5 real usernames from the database
          _row('admin',       'Administrator'),
          _row('dispatcher1', 'Dispatcher'),
          _row('driver1',     'Driver'),
          _row('driver2',     'Driver'),
          _row('driver3',     'Driver'),
          const SizedBox(height: 4),
          const Text(
            'Use each account\'s own password',
            style: TextStyle(
              fontSize: 10,
              color:    AppTheme.textHint,
              fontStyle: FontStyle.italic,
            ),
          ),
        ],
      ),
    );
  }

  Widget _row(String username, String role) {
    return Padding(
      padding: const EdgeInsets.only(top: 3),
      child: Row(
        children: [
          Text(
            username,
            style: const TextStyle(
              fontSize:   11,
              color:      AppTheme.textSecondary,
              fontFamily: 'monospace',
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(width: 8),
          Text(
            '— $role',
            style: const TextStyle(fontSize: 10, color: AppTheme.textHint),
          ),
        ],
      ),
    );
  }
}
