// ============================================
// FILE: lib/services/api_service.dart
// PURPOSE: Base HTTP client - all services use this
// LAYER: Service Layer (lowest level - talks to network)
//
// CHANGE FROM ORIGINAL:
//   Only the _headers getter is updated — it now injects
//   Authorization: Bearer <token> from AuthService.
//   Every other method (get/post/put/delete, _handleResponse,
//   _handleError, ApiException) is IDENTICAL to your original.
// ============================================

import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:vehicle_scheduling_app/config/app_config.dart';
import 'package:vehicle_scheduling_app/services/auth_service.dart';

class ApiService {
  final String     baseUrl     = AppConfig.baseUrl;
  final http.Client _client    = http.Client();
  final AuthService _authService = AuthService(); // singleton — no extra cost

  // ==========================================
  // HEADERS
  // Now injects JWT Bearer token automatically.
  // All your existing services (JobService, VehicleService)
  // call get/post/etc which use this getter — zero changes needed there.
  // ==========================================
  Map<String, String> get _headers {
    final token = _authService.accessToken;
    return {
      'Content-Type': 'application/json',
      'Accept':       'application/json',
      if (token != null) 'Authorization': 'Bearer $token',
    };
  }

  // ==========================================
  // GET REQUEST
  // ==========================================
  Future<Map<String, dynamic>> get(String endpoint) async {
    try {
      print('GET $baseUrl$endpoint');
      final response = await _client
          .get(Uri.parse('$baseUrl$endpoint'), headers: _headers)
          .timeout(AppConfig.connectionTimeout);
      return _handleResponse(response);
    } catch (e) {
      print('GET error: $e');
      throw _handleError(e);
    }
  }

  // ==========================================
  // POST REQUEST
  // ==========================================
  Future<Map<String, dynamic>> post(
    String endpoint, {
    Map<String, dynamic>? data,
  }) async {
    try {
      print('POST $baseUrl$endpoint');
      final response = await _client
          .post(
            Uri.parse('$baseUrl$endpoint'),
            headers: _headers,
            body:    data != null ? jsonEncode(data) : null,
          )
          .timeout(AppConfig.connectionTimeout);
      return _handleResponse(response);
    } catch (e) {
      print('POST error: $e');
      throw _handleError(e);
    }
  }

  // ==========================================
  // PUT REQUEST
  // ==========================================
  Future<Map<String, dynamic>> put(
    String endpoint, {
    Map<String, dynamic>? data,
  }) async {
    try {
      print('PUT $baseUrl$endpoint');
      final response = await _client
          .put(
            Uri.parse('$baseUrl$endpoint'),
            headers: _headers,
            body:    data != null ? jsonEncode(data) : null,
          )
          .timeout(AppConfig.connectionTimeout);
      return _handleResponse(response);
    } catch (e) {
      print('PUT error: $e');
      throw _handleError(e);
    }
  }

  // ==========================================
  // DELETE REQUEST
  // ==========================================
  Future<Map<String, dynamic>> delete(String endpoint) async {
    try {
      print('DELETE $baseUrl$endpoint');
      final response = await _client
          .delete(Uri.parse('$baseUrl$endpoint'), headers: _headers)
          .timeout(AppConfig.connectionTimeout);
      return _handleResponse(response);
    } catch (e) {
      print('DELETE error: $e');
      throw _handleError(e);
    }
  }

  // ==========================================
  // HANDLE RESPONSE (PRIVATE) — unchanged
  // ==========================================
  Map<String, dynamic> _handleResponse(http.Response response) {
    print('Response ${response.statusCode}');

    if (response.statusCode >= 200 && response.statusCode < 300) {
      try {
        return jsonDecode(response.body) as Map<String, dynamic>;
      } catch (e) {
        throw ApiException('Failed to parse server response', 500);
      }
    }

    String errorMessage = 'Request failed (${response.statusCode})';
    try {
      final errorJson = jsonDecode(response.body) as Map<String, dynamic>;
      errorMessage = errorJson['message'] ?? errorJson['error'] ?? errorMessage;
    } catch (_) {
      if (response.body.isNotEmpty) errorMessage = response.body;
    }

    throw ApiException(errorMessage, response.statusCode);
  }

  // ==========================================
  // HANDLE ERROR (PRIVATE) — unchanged
  // ==========================================
  Exception _handleError(dynamic error) {
    if (error is ApiException) return error;

    if (error.toString().contains('SocketException') ||
        error.toString().contains('Failed host lookup')) {
      return ApiException(
        'Cannot reach server. Make sure your backend is running on port 3000.',
        0,
      );
    }

    if (error.toString().contains('TimeoutException')) {
      return ApiException('Request timed out. Please try again.', 0);
    }

    return ApiException('Unexpected error: ${error.toString()}', 0);
  }

  // ==========================================
  // DISPOSE — unchanged
  // ==========================================
  void dispose() {
    _client.close();
  }
}

// ============================================
// API EXCEPTION — unchanged from your original
// ============================================
class ApiException implements Exception {
  final String message;
  final int    statusCode;

  const ApiException(this.message, this.statusCode);

  @override
  String toString() => message;

  bool get isValidationError => statusCode == 400;
  bool get isUnauthorized    => statusCode == 401;
  bool get isForbidden       => statusCode == 403;
  bool get isNotFound        => statusCode == 404;
  bool get isConflict        => statusCode == 409;
  bool get isServerError     => statusCode >= 500;
  bool get isNetworkError    => statusCode == 0;
}
