// ============================================
// FILE: lib/services/auth_service.dart
// PURPOSE: JWT token management and auth API calls
// ============================================
//
// SINGLETON — one instance shared across the app.
// ApiService reads .accessToken synchronously (no async needed).
// AuthProvider calls the async methods (login, logout, etc).

import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:vehicle_scheduling_app/config/app_config.dart';
import 'package:vehicle_scheduling_app/models/user.dart';

class AuthService {
  // ── Singleton setup ───────────────────────────────────────────────────────
  static final AuthService _instance = AuthService._internal();
  factory AuthService() => _instance;
  AuthService._internal();

  // ── In-memory state (read synchronously by ApiService) ───────────────────
  String? _accessToken;
  String? _refreshToken;
  User?   _currentUser;

  String? get accessToken => _accessToken;
  User?   get currentUser => _currentUser;
  bool    get isLoggedIn  => _accessToken != null && _currentUser != null;

  // ============================================
  // INIT — called once by AuthProvider on app start
  // Loads saved tokens from device storage
  // ============================================
  Future<void> init() async {
    final prefs = await SharedPreferences.getInstance();
    _accessToken  = prefs.getString(AppConfig.accessTokenKey);
    _refreshToken = prefs.getString(AppConfig.refreshTokenKey);

    final userJson = prefs.getString(AppConfig.userDataKey);
    if (userJson != null) {
      try {
        _currentUser = User.fromJson(
          jsonDecode(userJson) as Map<String, dynamic>,
        );
      } catch (_) {
        await _clearStorage(); // corrupt data → clean start
      }
    }
  }

  // ============================================
  // VALIDATE TOKEN — called by AuthProvider after init()
  // Pings /api/auth/me. On 401 tries to refresh first.
  // Returns true if a valid session was established.
  // ============================================
  Future<bool> validateToken() async {
    if (_accessToken == null) return false;

    try {
      final response = await http
          .get(
            Uri.parse('${AppConfig.baseUrl}${AppConfig.meEndpoint}'),
            headers: _bearerHeaders,
          )
          .timeout(AppConfig.connectionTimeout);

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body) as Map<String, dynamic>;
        _currentUser = User.fromJson(data['user'] as Map<String, dynamic>);
        await _saveUser();
        return true;
      }

      if (response.statusCode == 401) {
        return await refreshTokens(); // try to renew
      }

      return false;
    } catch (_) {
      // Network unreachable — trust cached user so app still opens
      return _currentUser != null;
    }
  }

  // ============================================
  // LOGIN
  // POST /api/auth/login
  // Returns { success: true, user: User }
  //      or { success: false, message: '...' }
  // ============================================
  Future<Map<String, dynamic>> login({
    required String username,
    required String password,
  }) async {
    try {
      final response = await http
          .post(
            Uri.parse('${AppConfig.baseUrl}${AppConfig.loginEndpoint}'),
            headers: {'Content-Type': 'application/json'},
            body: jsonEncode({'username': username, 'password': password}),
          )
          .timeout(AppConfig.connectionTimeout);

      final data = jsonDecode(response.body) as Map<String, dynamic>;

      if (response.statusCode == 200 && data['success'] == true) {
        _accessToken  = data['accessToken']  as String;
        _refreshToken = data['refreshToken'] as String;
        _currentUser  = User.fromJson(data['user'] as Map<String, dynamic>);
        await _saveAll();
        return {'success': true, 'user': _currentUser};
      }

      return {
        'success': false,
        'message': data['message'] as String? ?? 'Login failed.',
      };
    } on Exception catch (e) {
      final msg = e.toString();
      if (msg.contains('SocketException') || msg.contains('Failed host lookup')) {
        return {'success': false, 'message': 'Cannot reach server. Is the backend running?'};
      }
      if (msg.contains('TimeoutException')) {
        return {'success': false, 'message': 'Connection timed out. Try again.'};
      }
      return {'success': false, 'message': 'Network error: $msg'};
    }
  }

  // ============================================
  // REFRESH TOKENS
  // Called automatically when access token expires (401).
  // Returns true on success (new tokens stored).
  // Returns false if refresh token also expired → force logout.
  // ============================================
  Future<bool> refreshTokens() async {
    if (_refreshToken == null) return false;

    try {
      final response = await http
          .post(
            Uri.parse('${AppConfig.baseUrl}${AppConfig.refreshEndpoint}'),
            headers: {'Content-Type': 'application/json'},
            body: jsonEncode({'refreshToken': _refreshToken}),
          )
          .timeout(AppConfig.connectionTimeout);

      final data = jsonDecode(response.body) as Map<String, dynamic>;

      if (response.statusCode == 200 && data['success'] == true) {
        _accessToken  = data['accessToken']  as String;
        _refreshToken = data['refreshToken'] as String;
        await _saveTokens();
        return true;
      }

      await _clearStorage(); // refresh failed → must log in again
      return false;
    } catch (_) {
      return false;
    }
  }

  // ============================================
  // LOGOUT
  // POST /api/auth/logout  (best-effort)
  // Always clears local storage even if server unreachable
  // ============================================
  Future<void> logout() async {
    if (_accessToken != null) {
      try {
        await http
            .post(
              Uri.parse('${AppConfig.baseUrl}${AppConfig.logoutEndpoint}'),
              headers: _bearerHeaders,
            )
            .timeout(const Duration(seconds: 8));
      } catch (_) {
        // Server down? Still clear locally.
      }
    }
    await _clearStorage();
  }

  // ── Private helpers ───────────────────────────────────────────────────────

  Map<String, String> get _bearerHeaders => {
    'Content-Type':  'application/json',
    'Authorization': 'Bearer ${_accessToken ?? ''}',
  };

  Future<void> _saveAll() async {
    await _saveTokens();
    await _saveUser();
  }

  Future<void> _saveTokens() async {
    final prefs = await SharedPreferences.getInstance();
    if (_accessToken  != null) await prefs.setString(AppConfig.accessTokenKey,  _accessToken!);
    if (_refreshToken != null) await prefs.setString(AppConfig.refreshTokenKey, _refreshToken!);
  }

  Future<void> _saveUser() async {
    if (_currentUser == null) return;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(AppConfig.userDataKey, jsonEncode(_currentUser!.toJson()));
  }

  Future<void> _clearStorage() async {
    _accessToken  = null;
    _refreshToken = null;
    _currentUser  = null;
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(AppConfig.accessTokenKey);
    await prefs.remove(AppConfig.refreshTokenKey);
    await prefs.remove(AppConfig.userDataKey);
  }
}
